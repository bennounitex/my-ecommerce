export type Size = 'XS' | 'S' | 'M' | 'L' | 'XL' | 'XXL' | number;

export type ProductCategory = 'ropa' | 'calzado' | 'bolsos';

export type ProductSubcategory =
  // Ropa
  | 'vestidos'
  | 'blusas'
  | 'pantalones'
  | 'faldas'
  | 'abrigos'
  | 'chaquetas'
  | 'suéteres'
  | 'camisetas'
  | 'conjuntos'
  // Calzado
  | 'zapatos'
  | 'botas'
  | 'sandalias'
  | 'deportivas'
  | 'tacones'
  // Bolsos
  | 'bandoleras'
  | 'mochilas'
  | 'clutch'
  | 'totes'
  | 'carteras';

export interface ProductImage {
  id: string;
  url: string;
  alt: string;
}

export interface ProductVariant {
  id: string;
  size: Size;
  color: string;
  colorCode: string;
  stock: number;
  sku: string;
}

export interface ProductReview {
  id: string;
  userId: string;
  username: string;
  rating: number;
  comment: string;
  date: Date;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  salePrice?: number;
  category: ProductCategory;
  subcategory: ProductSubcategory;
  images: ProductImage[];
  variants: ProductVariant[];
  reviews: ProductReview[];
  featured: boolean;
  isNew: boolean;
  createdAt: Date;
  updatedAt: Date;
}