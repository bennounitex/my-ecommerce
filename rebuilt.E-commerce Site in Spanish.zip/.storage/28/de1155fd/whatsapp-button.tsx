import { MessageCircle } from 'lucide-react';
import { Button } from './button';
import { cn } from '@/lib/utils';

interface WhatsAppButtonProps {
  className?: string;
  phoneNumber?: string;
}

export default function WhatsAppButton({ 
  className,
  phoneNumber = '34600000000', // Default phone number, replace with real one
}: WhatsAppButtonProps) {
  const handleWhatsAppClick = () => {
    window.open(`https://wa.me/${phoneNumber}`, '_blank');
  };

  return (
    <Button
      onClick={handleWhatsAppClick}
      className={cn(
        "fixed bottom-4 right-4 bg-green-500 hover:bg-green-600 text-white rounded-full shadow-lg z-50 transition-all duration-300 ease-in-out transform hover:scale-110",
        className
      )}
      size="icon"
    >
      <MessageCircle className="h-6 w-6" />
      <span className="sr-only">Contactar por WhatsApp</span>
    </Button>
  );
}