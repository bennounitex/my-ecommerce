import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useProductStore } from '@/store/productStore';
import ProductGrid from '@/components/product/ProductGrid';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { ArrowRight, Star } from 'lucide-react';
import WhatsAppButton from '@/components/ui/whatsapp-button';

export default function Home() {
  const { 
    featuredProducts, 
    newProducts, 
    fetchProducts, 
    isLoading 
  } = useProductStore();

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  // Categories for showcase
  const categories = [
    { name: 'Vestidos', slug: 'vestidos', image: '/assets/categories/placeholder.jpg' },
    { name: 'Blusas', slug: 'blusas', image: '/assets/categories/placeholder.jpg' },
    { name: 'Pantalones', slug: 'pantalones', image: '/assets/categories/placeholder.jpg' },
    { name: 'Calzado', slug: 'calzado', image: '/assets/categories/placeholder.jpg' },
    { name: 'Bolsos', slug: 'bolsos', image: '/assets/categories/placeholder.jpg' },
    { name: 'Accesorios', slug: 'accesorios', image: '/assets/categories/placeholder.jpg' },
  ];

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-primary/5">
        <div className="container px-4 md:px-6 space-y-10 xl:space-y-16">
          <div className="grid gap-4 px-4 sm:px-6 md:px-10 md:grid-cols-2 md:gap-16">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Moda Elegante para Mujer
                </h1>
                <p className="max-w-[600px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Descubre nuestra nueva colección de primavera-verano con las últimas tendencias en moda femenina. Prendas de calidad diseñadas para la mujer moderna.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link to="/productos">
                  <Button size="lg" className="px-8">
                    Ver Colección
                  </Button>
                </Link>
                <Link to="/quienes-somos">
                  <Button size="lg" variant="outline">
                    Sobre Nosotros
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <img
                alt="Moda elegante para mujer"
                className="object-cover rounded-lg aspect-video overflow-hidden"
                height={310}
                src="/assets/categories/placeholder.jpg"
                width={550}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="w-full py-12 md:py-24 bg-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-muted px-3 py-1 text-sm">
                Destacados
              </div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                Productos Destacados
              </h2>
              <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
                Descubre nuestras selecciones destacadas de ropa, calzado y accesorios para mujer
              </p>
            </div>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="mx-auto w-full max-w-5xl">
              <ProductGrid products={featuredProducts} columns={4} />
            </div>
          )}
          
          <div className="flex justify-center mt-8">
            <Link to="/productos">
              <Button variant="outline" className="group">
                Ver todos los productos
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="w-full py-12 md:py-24 bg-muted/30">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                Explora Nuestras Categorías
              </h2>
              <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
                Encuentra lo que buscas en nuestras colecciones cuidadosamente seleccionadas
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
            {categories.map((category) => (
              <Link 
                to={`/categoria/${category.slug}`} 
                key={category.slug}
                className="group relative overflow-hidden rounded-lg hover:shadow-lg transition-all duration-300"
              >
                <div className="aspect-square overflow-hidden">
                  <img 
                    src={category.image} 
                    alt={category.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
                    <h3 className="text-white text-lg md:text-xl font-bold">{category.name}</h3>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      {newProducts.length > 0 && (
        <section className="w-full py-12 md:py-24 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary/10 text-primary px-3 py-1 text-sm font-medium">
                  Novedades
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                  Recién Llegados
                </h2>
                <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
                  Las últimas incorporaciones a nuestro catálogo, diseñadas para impresionar
                </p>
              </div>
            </div>
            
            <Carousel
              opts={{
                align: "start",
                loop: true,
              }}
              className="w-full"
            >
              <CarouselContent>
                {newProducts.map((product) => (
                  <CarouselItem key={product.id} className="md:basis-1/2 lg:basis-1/3">
                    <div className="p-1">
                      <Card>
                        <CardContent className="p-0">
                          <Link to={`/producto/${product.slug}`}>
                            <div className="aspect-square overflow-hidden rounded-t-lg bg-muted">
                              <img 
                                src={product.images[0]?.url || '/assets/products/placeholder.jpg'} 
                                alt={product.name}
                                className="h-full w-full object-cover transition-all hover:scale-105"
                              />
                              {product.new && (
                                <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs font-medium px-2 py-1 rounded">
                                  Nuevo
                                </div>
                              )}
                            </div>
                            <div className="p-4">
                              <h3 className="font-medium text-lg truncate">{product.name}</h3>
                              <p className="text-sm text-muted-foreground truncate">{product.brand}</p>
                              <div className="flex items-center justify-between mt-2">
                                <div className="flex items-center gap-2">
                                  {product.salePrice ? (
                                    <>
                                      <span className="font-semibold">{product.salePrice.toFixed(2)} €</span>
                                      <span className="text-sm text-muted-foreground line-through">{product.basePrice.toFixed(2)} €</span>
                                    </>
                                  ) : (
                                    <span className="font-semibold">{product.basePrice.toFixed(2)} €</span>
                                  )}
                                </div>
                                <div className="flex items-center text-amber-500">
                                  <Star className="h-4 w-4 fill-current" />
                                  <span className="text-xs font-medium ml-1">{product.rating.toFixed(1)}</span>
                                </div>
                              </div>
                            </div>
                          </Link>
                        </CardContent>
                      </Card>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious />
              <CarouselNext />
            </Carousel>
          </div>
        </section>
      )}

      {/* Benefits/Features */}
      <section className="w-full py-12 md:py-24 bg-muted/30">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <div className="flex flex-col items-center text-center space-y-2 p-4 rounded-lg bg-background shadow-sm">
              <div className="p-2 bg-primary/10 rounded-full">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-6 w-6 text-primary"
                >
                  <path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"></path>
                  <path d="m9.2 22 3-7"></path>
                  <path d="m9.7 18.6 3.5-3.5"></path>
                  <path d="m14.5 14.5-3.5 3.5"></path>
                </svg>
              </div>
              <h3 className="text-lg font-bold">Envío Rápido</h3>
              <p className="text-sm text-muted-foreground">
                Recibe tu pedido en 24-48h en toda la península
              </p>
            </div>
            <div className="flex flex-col items-center text-center space-y-2 p-4 rounded-lg bg-background shadow-sm">
              <div className="p-2 bg-primary/10 rounded-full">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-6 w-6 text-primary"
                >
                  <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>
                </svg>
              </div>
              <h3 className="text-lg font-bold">Calidad Garantizada</h3>
              <p className="text-sm text-muted-foreground">
                Materiales premium y acabados cuidados
              </p>
            </div>
            <div className="flex flex-col items-center text-center space-y-2 p-4 rounded-lg bg-background shadow-sm">
              <div className="p-2 bg-primary/10 rounded-full">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-6 w-6 text-primary"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"></path>
                </svg>
              </div>
              <h3 className="text-lg font-bold">Pagos Seguros</h3>
              <p className="text-sm text-muted-foreground">
                Transacciones 100% seguras y cifradas
              </p>
            </div>
            <div className="flex flex-col items-center text-center space-y-2 p-4 rounded-lg bg-background shadow-sm">
              <div className="p-2 bg-primary/10 rounded-full">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-6 w-6 text-primary"
                >
                  <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path>
                  <path d="M12 9v4"></path>
                  <path d="M12 17h.01"></path>
                </svg>
              </div>
              <h3 className="text-lg font-bold">Devoluciones Sencillas</h3>
              <p className="text-sm text-muted-foreground">
                14 días para cambios y devoluciones
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">
                ¿Tienes preguntas?
              </h2>
              <p className="mx-auto max-w-[600px] text-primary-foreground/80 md:text-xl/relaxed">
                Nuestro equipo de atención al cliente está aquí para ayudarte con cualquier duda sobre nuestros productos o pedidos.
              </p>
            </div>
            <div className="w-full max-w-sm space-y-2">
              <WhatsAppButton className="w-full" />
              <p className="text-xs text-primary-foreground/70">
                También puedes llamarnos al +34 932 556 789 o enviarnos un email a info@bennounitex.com
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}