import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Cart, CartItem, ProductVariant } from '@/types';

const initialCartState: Cart = {
  items: [],
  subtotal: 0,
  shippingCost: 0,
  discount: 0,
  total: 0,
};

export const useCartStore = create<
  Cart & {
    addItem: (productId: string, productName: string, productImage: string, variant: ProductVariant, price: number, quantity: number) => void;
    removeItem: (id: string) => void;
    updateQuantity: (id: string, quantity: number) => void;
    applyCoupon: (code: string) => void;
    removeCoupon: () => void;
    calculateTotals: () => void;
    clearCart: () => void;
  }
>()(
  persist(
    (set, get) => ({
      ...initialCartState,

      addItem: (productId, productName, productImage, variant, price, quantity) => {
        set((state) => {
          // Check if item already exists in cart
          const existingItemIndex = state.items.findIndex(
            (item) => item.productId === productId && item.variant.id === variant.id
          );

          const newItems: CartItem[] = [...state.items];

          if (existingItemIndex >= 0) {
            // Update existing item
            newItems[existingItemIndex] = {
              ...newItems[existingItemIndex],
              quantity: newItems[existingItemIndex].quantity + quantity,
              subtotal: (newItems[existingItemIndex].quantity + quantity) * price,
            };
          } else {
            // Add new item
            newItems.push({
              id: crypto.randomUUID(),
              productId,
              productName,
              productImage,
              variant,
              price,
              quantity,
              subtotal: price * quantity,
            });
          }

          // Return new state
          return { items: newItems };
        });

        // Calculate new totals after adding item
        get().calculateTotals();
      },

      removeItem: (id) => {
        set((state) => ({
          items: state.items.filter((item) => item.id !== id),
        }));
        get().calculateTotals();
      },

      updateQuantity: (id, quantity) => {
        set((state) => ({
          items: state.items.map((item) =>
            item.id === id
              ? { ...item, quantity, subtotal: item.price * quantity }
              : item
          ),
        }));
        get().calculateTotals();
      },

      applyCoupon: (code) => {
        // In a real app, this would validate the coupon with backend
        // For now, we'll simulate a simple discount
        const discountAmount = get().subtotal * 0.1; // 10% discount
        set({
          discount: discountAmount,
          couponCode: code,
        });
        get().calculateTotals();
      },

      removeCoupon: () => {
        set({
          discount: 0,
          couponCode: undefined,
        });
        get().calculateTotals();
      },

      calculateTotals: () => {
        set((state) => {
          const subtotal = state.items.reduce((sum, item) => sum + item.subtotal, 0);
          
          // Calculate shipping cost based on subtotal
          // Free shipping for orders over €50
          const shippingCost = subtotal > 50 ? 0 : 4.99;
          
          const total = subtotal + shippingCost - state.discount;
          
          return {
            subtotal,
            shippingCost,
            total,
          };
        });
      },

      clearCart: () => {
        set(initialCartState);
      },
    }),
    {
      name: 'cart-storage',
    }
  )
);