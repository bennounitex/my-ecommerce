import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, Search, ShoppingBag, User, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from '@/components/ui/navigation-menu';
import { useCartStore } from '@/store/cartStore';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

const categories = [
  {
    title: 'Ropa',
    href: '/categorias/ropa',
    subcategories: [
      { title: 'Vestidos', href: '/categorias/ropa/vestidos' },
      { title: 'Blusas', href: '/categorias/ropa/blusas' },
      { title: 'Pantalones', href: '/categorias/ropa/pantalones' },
      { title: 'Faldas', href: '/categorias/ropa/faldas' },
    ],
  },
  {
    title: 'Calzado',
    href: '/categorias/calzado',
    subcategories: [
      { title: 'Zapatos', href: '/categorias/calzado/zapatos' },
      { title: 'Botas', href: '/categorias/calzado/botas' },
      { title: 'Sandalias', href: '/categorias/calzado/sandalias' },
    ],
  },
  {
    title: 'Bolsos',
    href: '/categorias/bolsos',
    subcategories: [
      { title: 'De mano', href: '/categorias/bolsos/mano' },
      { title: 'Mochilas', href: '/categorias/bolsos/mochilas' },
      { title: 'Bandoleras', href: '/categorias/bolsos/bandoleras' },
    ],
  },
];

export default function Header() {
  const [searchQuery, setSearchQuery] = useState('');
  const cart = useCartStore((state) => state.items);
  const navigate = useNavigate();
  
  const cartItemCount = cart.reduce((count, item) => count + item.quantity, 0);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/buscar?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b border-gray-200">
      <div className="container px-4 md:px-6 py-3 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <span className="font-bold text-xl md:text-2xl text-primary">BENNOUNI TEX</span>
        </Link>
        
        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center space-x-6">
          <NavigationMenu>
            <NavigationMenuList>
              {categories.map((category) => (
                <NavigationMenuItem key={category.title}>
                  <NavigationMenuTrigger>{category.title}</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4">
                      <li className="row-span-3">
                        <NavigationMenuLink asChild>
                          <Link
                            to={category.href}
                            className="flex h-full w-full select-none flex-col justify-end rounded-md bg-gradient-to-b from-muted/50 to-muted p-6 no-underline outline-none focus:shadow-md"
                          >
                            <div className="mb-2 mt-4 text-lg font-medium">
                              Ver todos los {category.title}
                            </div>
                            <p className="text-sm leading-tight text-muted-foreground">
                              Explora nuestra colección completa de {category.title.toLowerCase()}
                            </p>
                          </Link>
                        </NavigationMenuLink>
                      </li>
                      {category.subcategories.map((subcategory) => (
                        <li key={subcategory.title}>
                          <NavigationMenuLink asChild>
                            <Link
                              to={subcategory.href}
                              className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                            >
                              <div className="text-sm font-medium leading-none">{subcategory.title}</div>
                            </Link>
                          </NavigationMenuLink>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              ))}
              <NavigationMenuItem>
                <Link to="/quienes-somos" className="text-sm font-medium transition-colors hover:text-primary">
                  ¿Quiénes Somos?
                </Link>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
        </div>
        
        {/* Desktop Search and Actions */}
        <div className="hidden lg:flex items-center space-x-4">
          {/* Search Bar */}
          <form onSubmit={handleSearch} className="relative w-64">
            <Input
              type="search"
              placeholder="Buscar productos..."
              className="pr-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button
              type="submit"
              size="icon"
              variant="ghost"
              className="absolute right-0 top-0 h-full"
            >
              <Search className="h-4 w-4" />
              <span className="sr-only">Buscar</span>
            </Button>
          </form>
          
          {/* User Account */}
          <Button variant="ghost" size="icon" asChild>
            <Link to="/cuenta">
              <User className="h-5 w-5" />
              <span className="sr-only">Mi cuenta</span>
            </Link>
          </Button>
          
          {/* Cart */}
          <Button variant="ghost" size="icon" asChild className="relative">
            <Link to="/carrito">
              <ShoppingBag className="h-5 w-5" />
              {cartItemCount > 0 && (
                <Badge
                  variant="destructive"
                  className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center rounded-full p-0 text-xs"
                >
                  {cartItemCount}
                </Badge>
              )}
              <span className="sr-only">Carrito</span>
            </Link>
          </Button>
        </div>
        
        {/* Mobile Menu Trigger */}
        <div className="flex items-center space-x-2 lg:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Abrir menú</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[80%] sm:w-[350px]">
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between py-4 border-b">
                  <span className="font-bold text-xl">BENNOUNI TEX</span>
                  <SheetTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <X className="h-5 w-5" />
                      <span className="sr-only">Cerrar menú</span>
                    </Button>
                  </SheetTrigger>
                </div>
                <div className="py-4">
                  <form onSubmit={handleSearch} className="relative mb-6">
                    <Input
                      type="search"
                      placeholder="Buscar productos..."
                      className="pr-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    <Button
                      type="submit"
                      size="icon"
                      variant="ghost"
                      className="absolute right-0 top-0 h-full"
                    >
                      <Search className="h-4 w-4" />
                      <span className="sr-only">Buscar</span>
                    </Button>
                  </form>
                  <div className="space-y-4">
                    <div className="font-medium">Categorías</div>
                    <div className="pl-1 space-y-1">
                      {categories.map((category) => (
                        <details key={category.title} className="group">
                          <summary className="flex cursor-pointer items-center justify-between py-2 text-sm hover:text-primary">
                            {category.title}
                            <span className="transition duration-300 group-open:rotate-180">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="h-4 w-4"
                              >
                                <polyline points="6 9 12 15 18 9"></polyline>
                              </svg>
                            </span>
                          </summary>
                          <ul className="mt-2 space-y-1 pl-4">
                            <li>
                              <Link
                                to={category.href}
                                className="block py-1 text-sm hover:text-primary"
                              >
                                Ver todo
                              </Link>
                            </li>
                            {category.subcategories.map((subcategory) => (
                              <li key={subcategory.title}>
                                <Link
                                  to={subcategory.href}
                                  className="block py-1 text-sm hover:text-primary"
                                >
                                  {subcategory.title}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </details>
                      ))}
                    </div>
                    <Link to="/quienes-somos" className="block py-2 text-sm hover:text-primary">
                      ¿Quiénes Somos?
                    </Link>
                    <Link to="/politica-devoluciones" className="block py-2 text-sm hover:text-primary">
                      Política de Devoluciones
                    </Link>
                    <Link to="/envio" className="block py-2 text-sm hover:text-primary">
                      Envío y Entrega
                    </Link>
                  </div>
                </div>
                <div className="mt-auto space-y-4 pt-4 border-t">
                  <Link
                    to="/cuenta"
                    className="flex items-center space-x-2 py-2 px-4 rounded-md hover:bg-accent"
                  >
                    <User className="h-5 w-5" />
                    <span>Mi cuenta</span>
                  </Link>
                  <Link
                    to="/carrito"
                    className="flex items-center justify-between py-2 px-4 rounded-md hover:bg-accent"
                  >
                    <div className="flex items-center space-x-2">
                      <ShoppingBag className="h-5 w-5" />
                      <span>Carrito</span>
                    </div>
                    {cartItemCount > 0 && (
                      <Badge variant="destructive" className="rounded-full">
                        {cartItemCount}
                      </Badge>
                    )}
                  </Link>
                </div>
              </div>
            </SheetContent>
          </Sheet>
          
          {/* Mobile Cart */}
          <Button variant="ghost" size="icon" asChild className="relative">
            <Link to="/carrito">
              <ShoppingBag className="h-5 w-5" />
              {cartItemCount > 0 && (
                <Badge
                  variant="destructive"
                  className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center rounded-full p-0 text-xs"
                >
                  {cartItemCount}
                </Badge>
              )}
              <span className="sr-only">Carrito</span>
            </Link>
          </Button>
        </div>
      </div>
    </header>
  );
}