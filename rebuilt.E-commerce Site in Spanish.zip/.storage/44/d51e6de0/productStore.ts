import { create } from 'zustand';
import { Product } from '@/types/product';

// This is a mock of what would be our API in a real project
// In production, this would be replaced with actual API calls
const fetchProductsApi = async (): Promise<Product[]> => {
  try {
    // In a real implementation, we would fetch from an API
    // For now, we'll import the JSON directly for simplicity
    // const response = await fetch('/products.json');
    // return await response.json();

    // Simulating a network request delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Sample products data
    return [
      {
        id: '1',
        slug: 'vestido-flores-primavera',
        name: 'Vestido de Flores Primavera',
        description: 'Elegante vestido floral ideal para la temporada de primavera. Confeccionado en tejido ligero y transpirable con estampado de flores.',
        brand: 'BENNOUNI TEX',
        basePrice: 49.95,
        salePrice: null,
        category: 'vestidos',
        tags: ['primavera', 'floral', 'casual'],
        images: [
          { url: '/assets/products/vestido-flores-1.jpg', alt: 'Vestido de Flores - Vista frontal' },
          { url: '/assets/products/vestido-flores-2.jpg', alt: 'Vestido de Flores - Vista posterior' }
        ],
        variants: [
          { id: '1-s', name: 'S', inStock: true },
          { id: '1-m', name: 'M', inStock: true },
          { id: '1-l', name: 'L', inStock: true },
          { id: '1-xl', name: 'XL', inStock: false }
        ],
        featured: true,
        new: false,
        rating: 4.7
      },
      {
        id: '2',
        slug: 'blusa-seda-elegante',
        name: 'Blusa de Seda Elegante',
        description: 'Blusa de seda premium con acabado elegante, perfecta para ocasiones especiales o para el día a día en la oficina.',
        brand: 'BENNOUNI TEX',
        basePrice: 39.95,
        salePrice: 29.95,
        category: 'blusas',
        tags: ['oficina', 'elegante', 'seda'],
        images: [
          { url: '/assets/products/blusa-seda-1.jpg', alt: 'Blusa de Seda - Vista frontal' },
          { url: '/assets/products/blusa-seda-2.jpg', alt: 'Blusa de Seda - Detalle' }
        ],
        variants: [
          { id: '2-s', name: 'S', inStock: true },
          { id: '2-m', name: 'M', inStock: true },
          { id: '2-l', name: 'L', inStock: true },
          { id: '2-xl', name: 'XL', inStock: true }
        ],
        featured: true,
        new: false,
        rating: 4.5
      },
      {
        id: '3',
        slug: 'pantalon-cintura-alta',
        name: 'Pantalón de Cintura Alta',
        description: 'Pantalón de cintura alta con corte recto, elegante y cómodo. Ideal para combinar con blusas y tops de diferentes estilos.',
        brand: 'BENNOUNI TEX',
        basePrice: 45.95,
        salePrice: null,
        category: 'pantalones',
        tags: ['oficina', 'formal', 'cintura alta'],
        images: [
          { url: '/assets/products/pantalon-1.jpg', alt: 'Pantalón - Vista frontal' },
          { url: '/assets/products/pantalon-2.jpg', alt: 'Pantalón - Vista posterior' }
        ],
        variants: [
          { id: '3-36', name: '36', inStock: true },
          { id: '3-38', name: '38', inStock: true },
          { id: '3-40', name: '40', inStock: true },
          { id: '3-42', name: '42', inStock: false },
          { id: '3-44', name: '44', inStock: false }
        ],
        featured: false,
        new: false,
        rating: 4.3
      },
      {
        id: '4',
        slug: 'zapatos-tacon-medio',
        name: 'Zapatos de Tacón Medio',
        description: 'Zapatos elegantes con tacón medio, cómodos para uso diario y lo suficientemente elegantes para ocasiones especiales.',
        brand: 'BENNOUNI TEX',
        basePrice: 59.95,
        salePrice: null,
        category: 'calzado',
        tags: ['tacones', 'elegante', 'oficina'],
        images: [
          { url: '/assets/products/zapatos-1.jpg', alt: 'Zapatos de Tacón - Vista lateral' },
          { url: '/assets/products/zapatos-2.jpg', alt: 'Zapatos de Tacón - Vista superior' }
        ],
        variants: [
          { id: '4-36', name: '36', inStock: true },
          { id: '4-37', name: '37', inStock: true },
          { id: '4-38', name: '38', inStock: true },
          { id: '4-39', name: '39', inStock: true },
          { id: '4-40', name: '40', inStock: false }
        ],
        featured: true,
        new: false,
        rating: 4.8
      },
      {
        id: '5',
        slug: 'bolso-bandolera-cuero',
        name: 'Bolso Bandolera de Cuero',
        description: 'Bolso bandolera elaborado en cuero genuino, con múltiples compartimentos y correa ajustable.',
        brand: 'BENNOUNI TEX',
        basePrice: 79.95,
        salePrice: 69.95,
        category: 'bolsos',
        tags: ['cuero', 'bandolera', 'casual'],
        images: [
          { url: '/assets/products/bolso-1.jpg', alt: 'Bolso Bandolera - Vista frontal' },
          { url: '/assets/products/bolso-2.jpg', alt: 'Bolso Bandolera - Vista interior' }
        ],
        variants: [
          { id: '5-black', name: 'Negro', inStock: true },
          { id: '5-brown', name: 'Marrón', inStock: true },
          { id: '5-red', name: 'Rojo', inStock: false }
        ],
        featured: true,
        new: true,
        rating: 4.9
      },
      {
        id: '6',
        slug: 'falda-plisada-midi',
        name: 'Falda Plisada Midi',
        description: 'Falda midi plisada con cintura elástica, elegante y versátil para cualquier ocasión.',
        brand: 'BENNOUNI TEX',
        basePrice: 42.95,
        salePrice: null,
        category: 'faldas',
        tags: ['plisada', 'midi', 'elegante'],
        images: [
          { url: '/assets/products/falda-1.jpg', alt: 'Falda Plisada - Vista frontal' },
          { url: '/assets/products/falda-2.jpg', alt: 'Falda Plisada - Detalle plisado' }
        ],
        variants: [
          { id: '6-s', name: 'S', inStock: true },
          { id: '6-m', name: 'M', inStock: true },
          { id: '6-l', name: 'L', inStock: false }
        ],
        featured: false,
        new: true,
        rating: 4.6
      },
      {
        id: '7',
        slug: 'botas-cuero-otono',
        name: 'Botas de Cuero Otoño',
        description: 'Botas de cuero para otoño, cómodas y resistentes con forro interior cálido.',
        brand: 'BENNOUNI TEX',
        basePrice: 89.95,
        salePrice: null,
        category: 'calzado',
        tags: ['botas', 'cuero', 'otoño'],
        images: [
          { url: '/assets/products/botas-1.jpg', alt: 'Botas de Cuero - Vista lateral' },
          { url: '/assets/products/botas-2.jpg', alt: 'Botas de Cuero - Vista frontal' }
        ],
        variants: [
          { id: '7-36', name: '36', inStock: true },
          { id: '7-37', name: '37', inStock: true },
          { id: '7-38', name: '38', inStock: true },
          { id: '7-39', name: '39', inStock: true },
          { id: '7-40', name: '40', inStock: true }
        ],
        featured: false,
        new: true,
        rating: 4.7
      },
      {
        id: '8',
        slug: 'vestido-noche-elegante',
        name: 'Vestido de Noche Elegante',
        description: 'Vestido largo de noche con detalles brillantes, perfecto para eventos especiales y galas.',
        brand: 'BENNOUNI TEX',
        basePrice: 129.95,
        salePrice: 99.95,
        category: 'vestidos',
        tags: ['noche', 'elegante', 'fiesta'],
        images: [
          { url: '/assets/products/vestido-noche-1.jpg', alt: 'Vestido de Noche - Vista frontal' },
          { url: '/assets/products/vestido-noche-2.jpg', alt: 'Vestido de Noche - Vista posterior' }
        ],
        variants: [
          { id: '8-s', name: 'S', inStock: true },
          { id: '8-m', name: 'M', inStock: true },
          { id: '8-l', name: 'L', inStock: true },
          { id: '8-xl', name: 'XL', inStock: true }
        ],
        featured: false,
        new: true,
        rating: 4.9
      }
    ];
  } catch (error) {
    console.error('Error fetching products:', error);
    return [];
  }
};

interface ProductState {
  products: Product[];
  featuredProducts: Product[];
  newProducts: Product[];
  isLoading: boolean;
  error: string | null;
  fetchProducts: () => Promise<void>;
  getProductBySlug: (slug: string) => Product | undefined;
  getProductsByCategory: (category: string, subcategory?: string) => Product[];
  getProductsBySearch: (query: string) => Product[];
  getFilteredProducts: (
    options: {
      category?: string;
      subcategory?: string;
      minPrice?: number;
      maxPrice?: number;
      brands?: string[];
      onSale?: boolean;
      inStock?: boolean;
      search?: string;
    }
  ) => Product[];
  getRelatedProducts: (product: Product, limit?: number) => Product[];
}

export const useProductStore = create<ProductState>((set, get) => ({
  products: [],
  featuredProducts: [],
  newProducts: [],
  isLoading: false,
  error: null,
  
  fetchProducts: async () => {
    set({ isLoading: true, error: null });
    
    try {
      const products = await fetchProductsApi();
      
      const featuredProducts = products.filter(p => p.featured);
      const newProducts = products.filter(p => p.new);
      
      set({ 
        products,
        featuredProducts,
        newProducts,
        isLoading: false 
      });
    } catch (error) {
      set({ 
        error: 'Error al cargar los productos. Por favor, inténtalo de nuevo más tarde.',
        isLoading: false 
      });
      console.error('Failed to fetch products:', error);
    }
  },
  
  getProductBySlug: (slug: string) => {
    return get().products.find(p => p.slug === slug);
  },
  
  getProductsByCategory: (category: string) => {
    return get().products.filter(p => p.category === category);
  },
  
  getRelatedProducts: (product: Product, limit = 4) => {
    const { products } = get();
    
    // Filter by same category but different product
    const sameCategory = products.filter(
      p => p.category === product.category && p.id !== product.id
    );
    
    // If we don't have enough products from the same category, add some from the same brand
    if (sameCategory.length < limit) {
      const sameBrand = products.filter(
        p => p.brand === product.brand && p.id !== product.id && p.category !== product.category
      );
      
      // Combine both arrays, removing duplicates
      const combined = [...sameCategory];
      
      for (const brandProduct of sameBrand) {
        if (combined.length < limit && !combined.find(p => p.id === brandProduct.id)) {
          combined.push(brandProduct);
        }
      }
      
      return combined;
    }
    
    // If we have more than enough products from the same category, return a random subset
    if (sameCategory.length > limit) {
      const shuffled = [...sameCategory].sort(() => 0.5 - Math.random());
      return shuffled.slice(0, limit);
    }
    
    return sameCategory;
  }
}));