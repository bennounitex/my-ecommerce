import { ProductVariant } from './product';

export interface CartItem {
  id: string;
  productId: string;
  productName: string;
  productImage: string;
  variant: ProductVariant;
  price: number;
  quantity: number;
  subtotal: number;
}

export interface Cart {
  items: CartItem[];
  subtotal: number;
  shippingCost: number;
  discount: number;
  total: number;
  couponCode?: string;
}

export interface CartState {
  cart: Cart;
  loading: boolean;
  error: string | null;
}