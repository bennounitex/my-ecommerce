import { Address } from './user';
import { ProductVariant } from './product';

export type OrderStatus = 
  | 'pendiente' 
  | 'pagado' 
  | 'preparando' 
  | 'enviado' 
  | 'entregado' 
  | 'cancelado';

export type PaymentMethod = 
  | 'tarjeta' 
  | 'paypal' 
  | 'transferencia' 
  | 'bizum';

export interface OrderItem {
  id: string;
  productId: string;
  productName: string;
  productImage: string;
  variant: ProductVariant;
  price: number;
  quantity: number;
  subtotal: number;
}

export interface Order {
  id: string;
  userId: string;
  orderNumber: string;
  items: OrderItem[];
  subtotal: number;
  shippingCost: number;
  discount: number;
  total: number;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentId?: string;
  shippingAddress: Address;
  billingAddress?: Address;
  notes?: string;
  trackingNumber?: string;
  createdAt: Date;
  updatedAt: Date;
}