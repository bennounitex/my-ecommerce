import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Send, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';

export default function Footer() {
  return (
    <footer className="bg-neutral-100 border-t border-gray-200">
      <div className="container px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand and About */}
          <div className="space-y-4">
            <Link to="/" className="inline-block">
              <span className="font-bold text-2xl text-primary">BENNOUNI TEX</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              Moda femenina elegante, cómoda y accesible para mujeres modernas.
            </p>
            <div className="flex space-x-4">
              <Button size="icon" variant="ghost" className="h-8 w-8">
                <Facebook className="h-4 w-4" />
                <span className="sr-only">Facebook</span>
              </Button>
              <Button size="icon" variant="ghost" className="h-8 w-8">
                <Instagram className="h-4 w-4" />
                <span className="sr-only">Instagram</span>
              </Button>
              <Button size="icon" variant="ghost" className="h-8 w-8">
                <Twitter className="h-4 w-4" />
                <span className="sr-only">Twitter</span>
              </Button>
            </div>
          </div>
          
          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Enlaces rápidos</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/quienes-somos" className="text-muted-foreground hover:text-primary transition-colors">
                  ¿Quiénes somos?
                </Link>
              </li>
              <li>
                <Link to="/politica-devoluciones" className="text-muted-foreground hover:text-primary transition-colors">
                  Política de devoluciones
                </Link>
              </li>
              <li>
                <Link to="/envio" className="text-muted-foreground hover:text-primary transition-colors">
                  Envío y entrega
                </Link>
              </li>
              <li>
                <Link to="/terminos" className="text-muted-foreground hover:text-primary transition-colors">
                  Términos y condiciones
                </Link>
              </li>
              <li>
                <Link to="/privacidad" className="text-muted-foreground hover:text-primary transition-colors">
                  Política de privacidad
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Categories */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Categorías</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/categorias/ropa/vestidos" className="text-muted-foreground hover:text-primary transition-colors">
                  Vestidos
                </Link>
              </li>
              <li>
                <Link to="/categorias/ropa/blusas" className="text-muted-foreground hover:text-primary transition-colors">
                  Blusas
                </Link>
              </li>
              <li>
                <Link to="/categorias/calzado" className="text-muted-foreground hover:text-primary transition-colors">
                  Calzado
                </Link>
              </li>
              <li>
                <Link to="/categorias/bolsos" className="text-muted-foreground hover:text-primary transition-colors">
                  Bolsos
                </Link>
              </li>
              <li>
                <Link to="/novedades" className="text-muted-foreground hover:text-primary transition-colors">
                  Novedades
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Newsletter and Contact */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Newsletter</h3>
            <p className="text-sm text-muted-foreground">
              Suscríbete para recibir novedades y ofertas exclusivas.
            </p>
            <form className="flex space-x-2">
              <Input type="email" placeholder="Tu email" className="flex-1" />
              <Button type="submit" size="icon" className="shrink-0">
                <Send className="h-4 w-4" />
                <span className="sr-only">Suscribirse</span>
              </Button>
            </form>
            <div className="pt-2">
              <h4 className="text-sm font-medium mb-2">¿Necesitas ayuda?</h4>
              <a href="https://wa.me/34600000000" target="_blank" rel="noopener noreferrer"
                 className="flex items-center text-sm text-primary hover:underline">
                <Phone className="h-4 w-4 mr-2" />
                <span>WhatsApp: +34 600 000 000</span>
              </a>
            </div>
          </div>
        </div>
        
        <Separator className="my-6" />
        
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground text-center md:text-left">
            © {new Date().getFullYear()} BENNOUNI TEX. Todos los derechos reservados.
          </p>
          <div className="flex items-center space-x-4">
            <img src="/assets/payment/visa.svg" alt="Visa" className="h-8 w-auto" />
            <img src="/assets/payment/mastercard.svg" alt="Mastercard" className="h-8 w-auto" />
            <img src="/assets/payment/paypal.svg" alt="PayPal" className="h-8 w-auto" />
          </div>
        </div>
      </div>
    </footer>
  );
}