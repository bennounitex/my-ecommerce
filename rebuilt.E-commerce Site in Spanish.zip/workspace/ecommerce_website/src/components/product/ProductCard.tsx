import { Product } from '@/types/product';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  showRating?: boolean;
}

export default function ProductCard({ product, showRating = true }: ProductCardProps) {
  // Handle potential missing properties in the product store
  // Since our store data doesn't fully match our type definition
  const images = product.images || [];
  const firstImage = images.length > 0 ? images[0]?.url : '/assets/products/placeholder.jpg';
  const altText = images.length > 0 ? images[0]?.alt || product.name : product.name;
  
  // Handle different property names between our store data and type definition
  const salePrice = 'salePrice' in product ? product.salePrice : undefined;
  const basePrice = 'basePrice' in product ? product.basePrice : product.price;
  const isNew = 'new' in product ? product.new : product.isNew;
  
  // Calculate discount percentage if there's a sale price
  const discountPercentage = salePrice ? Math.round(((basePrice - salePrice) / basePrice) * 100) : 0;

  return (
    <Card className="h-full overflow-hidden transition-all duration-200 hover:shadow-md">
      <Link to={`/producto/${product.slug}`}>
        <div className="relative aspect-square overflow-hidden bg-muted">
          <img 
            src={firstImage} 
            alt={altText}
            className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
          />
          
          {/* Badges for new or sale items */}
          <div className="absolute top-2 right-2 flex flex-col gap-1">
            {isNew && (
              <Badge variant="default" className="bg-blue-500">
                Nuevo
              </Badge>
            )}
            
            {salePrice && (
              <Badge variant="destructive" className="bg-red-500">
                {`-${discountPercentage}%`}
              </Badge>
            )}
          </div>
        </div>
      </Link>
      
      <CardContent className="p-4">
        <Link to={`/producto/${product.slug}`}>
          <div className="space-y-1">
            <h3 className="font-medium text-base hover:underline truncate">{product.name}</h3>
            
            {/* Brand name if available */}
            {'brand' in product && product.brand && (
              <p className="text-xs text-muted-foreground">{product.brand}</p>
            )}
            
            <div className="flex items-center justify-between pt-1">
              {/* Price display */}
              <div className="flex items-center gap-2">
                {salePrice ? (
                  <>
                    <span className="font-semibold text-red-600">{salePrice.toFixed(2)} €</span>
                    <span className="text-sm text-muted-foreground line-through">{basePrice.toFixed(2)} €</span>
                  </>
                ) : (
                  <span className="font-semibold">{basePrice.toFixed(2)} €</span>
                )}
              </div>
              
              {/* Rating display */}
              {showRating && 'rating' in product && product.rating && (
                <div className="flex items-center text-amber-500">
                  <Star className="h-3 w-3 fill-current" />
                  <span className="text-xs font-medium ml-1">{product.rating.toFixed(1)}</span>
                </div>
              )}
            </div>
          </div>
        </Link>
      </CardContent>
    </Card>
  );
}