import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useCartStore } from '@/store/cartStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { 
  ShoppingCart, 
  Trash2, 
  ChevronLeft, 
  AlertCircle,
  CreditCard,
  Truck,
  ShieldCheck
} from 'lucide-react';

export default function Cart() {
  const { 
    items, 
    subtotal, 
    shippingCost, 
    discount, 
    total, 
    couponCode,
    removeItem, 
    updateQuantity,
    applyCoupon,
    removeCoupon,
    calculateTotals
  } = useCartStore();

  // Local state for coupon input
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');
  
  // Calculate totals on component mount
  useEffect(() => {
    calculateTotals();
  }, [calculateTotals]);

  // Handle coupon application
  const handleApplyCoupon = () => {
    if (couponInput.trim()) {
      // In a real app, we would validate the coupon code with the backend
      // For now, accept any input as a valid coupon
      applyCoupon(couponInput);
      setCouponInput('');
      setCouponError('');
    } else {
      setCouponError('Por favor, introduce un código de cupón válido');
    }
  };

  // Empty cart state
  if (items.length === 0) {
    return (
      <div className="container py-16">
        <h1 className="text-3xl font-bold mb-6">Tu carrito</h1>
        <div className="bg-muted p-8 rounded-lg text-center mb-8">
          <ShoppingCart className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
          <h2 className="text-2xl font-bold mb-4">Tu carrito está vacío</h2>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Parece que aún no has añadido ningún producto a tu carrito. Explora nuestra colección para descubrir productos increíbles.
          </p>
          <Button size="lg" asChild>
            <Link to="/">Explorar productos</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-8">
      {/* Back button */}
      <div className="mb-6">
        <Button
          variant="ghost"
          size="sm"
          className="flex items-center text-muted-foreground hover:text-foreground"
          asChild
        >
          <Link to="/">
            <ChevronLeft className="h-4 w-4 mr-1" />
            Continuar comprando
          </Link>
        </Button>
      </div>

      <h1 className="text-3xl font-bold mb-8">Tu carrito</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2">
          <div className="space-y-4">
            {items.map((item) => (
              <div key={item.id} className="flex gap-4 p-4 border rounded-lg">
                {/* Product image */}
                <Link to={`/producto/${item.productId}`} className="w-24 h-24 flex-shrink-0">
                  <img 
                    src={item.productImage || '/assets/products/placeholder.jpg'} 
                    alt={item.productName}
                    className="w-full h-full object-cover rounded-md" 
                  />
                </Link>
                
                {/* Product details */}
                <div className="flex-grow">
                  <div className="flex justify-between">
                    <Link to={`/producto/${item.productId}`}>
                      <h3 className="font-medium hover:underline">{item.productName}</h3>
                    </Link>
                    <span className="font-semibold">{item.subtotal.toFixed(2)} €</span>
                  </div>
                  
                  <p className="text-sm text-muted-foreground">
                    Talla: {item.variant.name}
                  </p>
                  
                  <div className="flex items-center justify-between mt-4">
                    {/* Quantity selector */}
                    <div className="flex items-center border rounded-md w-24">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-none px-2"
                        onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                      >
                        -
                      </Button>
                      <span className="flex-1 text-center text-sm">{item.quantity}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-none px-2"
                        onClick={() => updateQuantity(item.id, Math.min(10, item.quantity + 1))}
                      >
                        +
                      </Button>
                    </div>
                    
                    {/* Remove button */}
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-muted-foreground hover:text-red-500"
                      onClick={() => removeItem(item.id)}
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Eliminar
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="border rounded-lg p-6 space-y-4 sticky top-8">
            <h2 className="text-xl font-bold mb-4">Resumen del pedido</h2>
            
            {/* Subtotal */}
            <div className="flex justify-between">
              <span className="text-muted-foreground">Subtotal</span>
              <span>{subtotal.toFixed(2)} €</span>
            </div>
            
            {/* Shipping */}
            <div className="flex justify-between">
              <span className="text-muted-foreground">Envío</span>
              {shippingCost > 0 ? (
                <span>{shippingCost.toFixed(2)} €</span>
              ) : (
                <span className="text-green-600">Gratis</span>
              )}
            </div>
            
            {/* Discount */}
            {discount > 0 && (
              <div className="flex justify-between">
                <span className="flex items-center text-muted-foreground">
                  Descuento
                  {couponCode && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-auto p-0 px-1 text-xs text-red-500 hover:text-red-700"
                      onClick={removeCoupon}
                    >
                      Eliminar
                    </Button>
                  )}
                </span>
                <span className="text-red-600">-{discount.toFixed(2)} €</span>
              </div>
            )}

            <Separator />
            
            {/* Total */}
            <div className="flex justify-between text-lg font-bold">
              <span>Total</span>
              <span>{total.toFixed(2)} €</span>
            </div>
            
            {/* Coupon Code */}
            <div className="pt-2">
              <label className="text-sm font-medium mb-2 block">
                ¿Tienes un código de descuento?
              </label>
              <div className="flex gap-2">
                <div className="flex-grow">
                  <Input 
                    placeholder="Introduce el código" 
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                  />
                  {couponError && (
                    <p className="text-xs text-red-500 mt-1">{couponError}</p>
                  )}
                </div>
                <Button onClick={handleApplyCoupon}>Aplicar</Button>
              </div>
              {couponCode && (
                <div className="text-sm text-green-600 mt-2 flex items-center">
                  <span>Cupón "{couponCode}" aplicado</span>
                </div>
              )}
            </div>
            
            {/* Checkout Button */}
            <Button size="lg" className="w-full mt-4">
              Proceder al pago
            </Button>
            
            {/* Info Message */}
            <div className="flex items-start gap-2 text-muted-foreground text-xs mt-4">
              <AlertCircle className="h-4 w-4 flex-shrink-0" />
              <p>Los impuestos y gastos de envío exactos se calcularán durante el proceso de pago según tu dirección de entrega.</p>
            </div>
            
            {/* Trust Badges */}
            <div className="pt-4 border-t mt-6">
              <div className="flex justify-between text-muted-foreground">
                <div className="flex flex-col items-center gap-1">
                  <CreditCard className="h-5 w-5" />
                  <span className="text-xs">Pago seguro</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <Truck className="h-5 w-5" />
                  <span className="text-xs">Envío rápido</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <ShieldCheck className="h-5 w-5" />
                  <span className="text-xs">Garantía</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}