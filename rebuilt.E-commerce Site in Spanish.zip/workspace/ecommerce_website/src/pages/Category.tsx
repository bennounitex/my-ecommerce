import { useEffect, useState } from 'react';
import { useParams, useSearchParams, Link } from 'react-router-dom';
import { useProductStore } from '@/store/productStore';
import ProductGrid from '@/components/product/ProductGrid';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  ChevronLeft, 
  ChevronRight, 
  SlidersHorizontal,
  X
} from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from '@/components/ui/sheet';
import { Product } from '@/types';

const categoryTranslations: Record<string, string> = {
  'ropa': 'Ropa',
  'calzado': 'Calzado',
  'bolsos': 'Bolsos',
  'vestidos': 'Vestidos',
  'blusas': 'Blusas',
  'pantalones': 'Pantalones',
  'faldas': 'Faldas',
  'zapatos': 'Zapatos',
  'botas': 'Botas',
  'sandalias': 'Sandalias',
  'mano': 'Bolsos de mano',
  'mochilas': 'Mochilas',
  'bandoleras': 'Bandoleras'
};

const sortOptions = [
  { label: 'Más recientes', value: 'latest' },
  { label: 'Precio: menor a mayor', value: 'price_asc' },
  { label: 'Precio: mayor a menor', value: 'price_desc' },
  { label: 'Popularidad', value: 'popularity' },
  { label: 'Mejor valorados', value: 'rating' },
];

export default function Category() {
  // Get category and subcategory from URL
  const { category, subcategory } = useParams<{ 
    category: string;
    subcategory?: string;
  }>();
  
  const [searchParams, setSearchParams] = useSearchParams();
  const { products, isLoading, fetchProducts } = useProductStore();
  
  // Filter and sort states
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 200]);
  const [sort, setSort] = useState(searchParams.get('sort') || 'latest');
  const [filters, setFilters] = useState<{
    brands: string[];
    onSale: boolean;
    inStock: boolean;
  }>({
    brands: [],
    onSale: false,
    inStock: true,
  });
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const productsPerPage = 12;

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);
  
  useEffect(() => {
    setCurrentPage(1); // Reset to first page when filters change
  }, [category, subcategory, filters, sort, priceRange]);

  // Update URL when sort changes
  useEffect(() => {
    const newSearchParams = new URLSearchParams(searchParams);
    if (sort !== 'latest') {
      newSearchParams.set('sort', sort);
    } else {
      newSearchParams.delete('sort');
    }
    setSearchParams(newSearchParams);
  }, [sort, setSearchParams, searchParams]);

  // Filter products based on category, subcategory, and filters
  const filteredProducts = products.filter((product) => {
    // Category filter
    if (category && !matchesCategory(product, category, subcategory)) {
      return false;
    }
    
    // Price filter
    const price = 'salePrice' in product ? product.salePrice : 
                 ('basePrice' in product ? product.basePrice : product.price);
    if (price < priceRange[0] || price > priceRange[1]) {
      return false;
    }
    
    // Brand filter
    if (filters.brands.length > 0 && 'brand' in product && product.brand) {
      if (!filters.brands.includes(product.brand)) {
        return false;
      }
    }
    
    // Sale filter
    if (filters.onSale && !('salePrice' in product)) {
      return false;
    }
    
    // In stock filter
    if (filters.inStock && product.variants && 
        !product.variants.some(variant => variant.inStock)) {
      return false;
    }
    
    return true;
  });
  
  // Sort filtered products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sort) {
      case 'price_asc':
        return getPriceForSorting(a) - getPriceForSorting(b);
      case 'price_desc':
        return getPriceForSorting(b) - getPriceForSorting(a);
      case 'rating':
        return (('rating' in b ? b.rating : 0) || 0) - 
               (('rating' in a ? a.rating : 0) || 0);
      case 'popularity':
        // Assuming we don't have real popularity data, use id as fallback
        return b.id.localeCompare(a.id);
      case 'latest':
      default:
        return b.id.localeCompare(a.id); // Assuming newer products have higher IDs
    }
  });
  
  // Extract all available brands for filtering
  const availableBrands = Array.from(
    new Set(
      products
        .filter(product => 'brand' in product && product.brand)
        .map(product => 'brand' in product ? product.brand : '')
        .filter(Boolean)
    )
  );
  
  // Get min and max price from all products
  const priceStats = products.reduce(
    (stats, product) => {
      const price = 'salePrice' in product ? product.salePrice : 
                   ('basePrice' in product ? product.basePrice : product.price);
      return {
        min: Math.min(stats.min, price),
        max: Math.max(stats.max, price),
      };
    },
    { min: Infinity, max: 0 }
  );
  
  // Update price range based on available products
  useEffect(() => {
    if (priceStats.min !== Infinity && priceStats.max !== 0) {
      setPriceRange([priceStats.min, priceStats.max]);
    }
  }, [priceStats.min, priceStats.max]);
  
  // Pagination
  const lastProductIndex = currentPage * productsPerPage;
  const firstProductIndex = lastProductIndex - productsPerPage;
  const currentProducts = sortedProducts.slice(firstProductIndex, lastProductIndex);
  const totalPages = Math.ceil(sortedProducts.length / productsPerPage);
  
  // Helper function to check if a product matches the category
  function matchesCategory(product: Product, cat: string, subcat?: string): boolean {
    // Check main category match
    if (product.category !== cat) {
      return false;
    }
    
    // If subcategory is specified, check that as well
    if (subcat && 'subcategory' in product && product.subcategory !== subcat) {
      return false;
    }
    
    return true;
  }
  
  // Helper function to get price for sorting
  function getPriceForSorting(product: Product): number {
    return 'salePrice' in product ? product.salePrice : 
          ('basePrice' in product ? product.basePrice : product.price);
  }
  
  // Toggle brand filter
  const toggleBrand = (brand: string) => {
    setFilters(prev => ({
      ...prev,
      brands: prev.brands.includes(brand)
        ? prev.brands.filter(b => b !== brand)
        : [...prev.brands, brand],
    }));
  };
  
  // Category title with translations
  const getCategoryTitle = (): string => {
    if (!category) return 'Todos los productos';
    
    const mainCategory = categoryTranslations[category] || category;
    if (!subcategory) return mainCategory;
    
    const subCategoryName = categoryTranslations[subcategory] || subcategory;
    return `${subCategoryName}`;
  };
  
  // Loading state
  if (isLoading) {
    return (
      <div className="container py-16 text-center">
        <p>Cargando productos...</p>
      </div>
    );
  }

  return (
    <div className="container py-8">
      {/* Breadcrumbs */}
      <nav className="flex mb-6 text-sm">
        <ol className="flex items-center space-x-2">
          <li>
            <Link to="/" className="text-muted-foreground hover:text-foreground">
              Inicio
            </Link>
          </li>
          <li>
            <span className="text-muted-foreground mx-2">/</span>
          </li>
          {category && (
            <>
              <li>
                <Link 
                  to={`/categorias/${category}`} 
                  className={`${!subcategory ? 'font-medium' : 'text-muted-foreground hover:text-foreground'}`}
                >
                  {categoryTranslations[category] || category}
                </Link>
              </li>
              {subcategory && (
                <>
                  <li>
                    <span className="text-muted-foreground mx-2">/</span>
                  </li>
                  <li className="font-medium">
                    {categoryTranslations[subcategory] || subcategory}
                  </li>
                </>
              )}
            </>
          )}
        </ol>
      </nav>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Filters - Desktop */}
        <div className="hidden md:block w-64 flex-shrink-0">
          <div className="space-y-6">
            <div>
              <h3 className="font-medium mb-4">Filtros</h3>
              
              {/* Price Range */}
              <div className="mb-8">
                <h4 className="text-sm font-medium mb-3">Precio</h4>
                <Slider
                  defaultValue={[priceRange[0], priceRange[1]]}
                  min={priceStats.min}
                  max={priceStats.max}
                  step={1}
                  onValueChange={(value) => setPriceRange([value[0], value[1]])}
                  className="mb-2"
                />
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span>{priceRange[0].toFixed(2)} €</span>
                  <span>{priceRange[1].toFixed(2)} €</span>
                </div>
              </div>
              
              {/* Brand Filter */}
              {availableBrands.length > 0 && (
                <div className="mb-8">
                  <h4 className="text-sm font-medium mb-3">Marca</h4>
                  <div className="space-y-2">
                    {availableBrands.map((brand) => (
                      <div key={brand} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`brand-${brand}`}
                          checked={filters.brands.includes(brand)}
                          onCheckedChange={() => toggleBrand(brand)}
                        />
                        <label 
                          htmlFor={`brand-${brand}`}
                          className="text-sm cursor-pointer"
                        >
                          {brand}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Other Filters */}
              <div>
                <h4 className="text-sm font-medium mb-3">Disponibilidad</h4>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="filter-sale"
                      checked={filters.onSale}
                      onCheckedChange={() => 
                        setFilters(prev => ({ ...prev, onSale: !prev.onSale }))
                      }
                    />
                    <label 
                      htmlFor="filter-sale"
                      className="text-sm cursor-pointer"
                    >
                      En oferta
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="filter-stock"
                      checked={filters.inStock}
                      onCheckedChange={() => 
                        setFilters(prev => ({ ...prev, inStock: !prev.inStock }))
                      }
                    />
                    <label 
                      htmlFor="filter-stock"
                      className="text-sm cursor-pointer"
                    >
                      En stock
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Products */}
        <div className="flex-1">
          {/* Header with filters and sort */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold">
                {getCategoryTitle()}
              </h1>
              <p className="text-muted-foreground">
                {sortedProducts.length} productos encontrados
              </p>
            </div>
            
            <div className="flex items-center gap-2">
              {/* Mobile Filter Button */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="sm" className="md:hidden">
                    <SlidersHorizontal className="h-4 w-4 mr-2" />
                    Filtros
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[80%] sm:w-[350px]">
                  <SheetHeader>
                    <SheetTitle>Filtros</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6 space-y-6">
                    {/* Price Range */}
                    <div>
                      <h4 className="text-sm font-medium mb-3">Precio</h4>
                      <Slider
                        defaultValue={[priceRange[0], priceRange[1]]}
                        min={priceStats.min}
                        max={priceStats.max}
                        step={1}
                        onValueChange={(value) => setPriceRange([value[0], value[1]])}
                        className="mb-2"
                      />
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>{priceRange[0].toFixed(2)} €</span>
                        <span>{priceRange[1].toFixed(2)} €</span>
                      </div>
                    </div>
                    
                    {/* Brand Filter */}
                    {availableBrands.length > 0 && (
                      <div>
                        <h4 className="text-sm font-medium mb-3">Marca</h4>
                        <div className="space-y-2">
                          {availableBrands.map((brand) => (
                            <div key={brand} className="flex items-center space-x-2">
                              <Checkbox 
                                id={`mobile-brand-${brand}`}
                                checked={filters.brands.includes(brand)}
                                onCheckedChange={() => toggleBrand(brand)}
                              />
                              <label 
                                htmlFor={`mobile-brand-${brand}`}
                                className="text-sm cursor-pointer"
                              >
                                {brand}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Other Filters */}
                    <div>
                      <h4 className="text-sm font-medium mb-3">Disponibilidad</h4>
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="mobile-filter-sale"
                            checked={filters.onSale}
                            onCheckedChange={() => 
                              setFilters(prev => ({ ...prev, onSale: !prev.onSale }))
                            }
                          />
                          <label 
                            htmlFor="mobile-filter-sale"
                            className="text-sm cursor-pointer"
                          >
                            En oferta
                          </label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="mobile-filter-stock"
                            checked={filters.inStock}
                            onCheckedChange={() => 
                              setFilters(prev => ({ ...prev, inStock: !prev.inStock }))
                            }
                          />
                          <label 
                            htmlFor="mobile-filter-stock"
                            className="text-sm cursor-pointer"
                          >
                            En stock
                          </label>
                        </div>
                      </div>
                    </div>
                    
                    <div className="pt-6 border-t flex justify-between">
                      <Button variant="outline" onClick={() => {
                        setFilters({ brands: [], onSale: false, inStock: true });
                        setPriceRange([priceStats.min, priceStats.max]);
                      }}>
                        <X className="h-4 w-4 mr-2" />
                        Limpiar
                      </Button>
                      <SheetClose asChild>
                        <Button>Aplicar filtros</Button>
                      </SheetClose>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
              
              {/* Sort Dropdown */}
              <div className="flex-1 sm:w-auto">
                <Select value={sort} onValueChange={setSort}>
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Ordenar por" />
                  </SelectTrigger>
                  <SelectContent>
                    {sortOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          {/* Active filters */}
          {(filters.brands.length > 0 || filters.onSale || !filters.inStock) && (
            <div className="flex flex-wrap gap-2 mb-4">
              {filters.brands.map((brand) => (
                <div 
                  key={brand} 
                  className="bg-muted text-sm px-3 py-1 rounded-full flex items-center gap-1"
                >
                  {brand}
                  <button onClick={() => toggleBrand(brand)} className="text-muted-foreground hover:text-foreground">
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
              
              {filters.onSale && (
                <div className="bg-muted text-sm px-3 py-1 rounded-full flex items-center gap-1">
                  En oferta
                  <button 
                    onClick={() => setFilters(prev => ({ ...prev, onSale: false }))} 
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              )}
              
              {!filters.inStock && (
                <div className="bg-muted text-sm px-3 py-1 rounded-full flex items-center gap-1">
                  Incluir sin stock
                  <button 
                    onClick={() => setFilters(prev => ({ ...prev, inStock: true }))} 
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              )}
              
              <button 
                onClick={() => {
                  setFilters({ brands: [], onSale: false, inStock: true });
                  setPriceRange([priceStats.min, priceStats.max]);
                }}
                className="text-primary text-sm hover:underline"
              >
                Limpiar filtros
              </button>
            </div>
          )}
          
          {/* Products Grid */}
          {currentProducts.length > 0 ? (
            <ProductGrid 
              products={currentProducts}
              columns={{ sm: 2, md: 3, lg: 3 }}
            />
          ) : (
            <div className="text-center py-16">
              <p className="text-muted-foreground mb-4">
                No se encontraron productos con los filtros seleccionados
              </p>
              <Button onClick={() => {
                setFilters({ brands: [], onSale: false, inStock: true });
                setPriceRange([priceStats.min, priceStats.max]);
              }}>
                Limpiar filtros
              </Button>
            </div>
          )}
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center mt-8">
              <div className="flex items-center gap-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
                  // Show current page, first, last, and pages around current
                  const shouldShow = 
                    page === 1 || 
                    page === totalPages || 
                    Math.abs(page - currentPage) <= 1;
                  
                  // Show ellipsis when needed
                  if (!shouldShow) {
                    if ((page === 2 && currentPage > 3) || 
                        (page === totalPages - 1 && currentPage < totalPages - 2)) {
                      return (
                        <span key={page} className="px-2">
                          ...
                        </span>
                      );
                    }
                    return null;
                  }
                  
                  return (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(page)}
                      className="w-8 h-8"
                    >
                      {page}
                    </Button>
                  );
                })}
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}