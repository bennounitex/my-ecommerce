import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useProductStore } from '@/store/productStore';
import { useCartStore } from '@/store/cartStore';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  ChevronLeft, 
  Star, 
  ShoppingCart, 
  Heart,
  Truck, 
  RotateCcw, 
  Shield,
  Check
} from 'lucide-react';
import ProductGrid from '@/components/product/ProductGrid';
import WhatsAppButton from '@/components/ui/whatsapp-button';
import { ProductVariant } from '@/types';

export default function ProductDetail() {
  const navigate = useNavigate();
  const { slug } = useParams<{ slug: string }>();
  const { 
    getProductBySlug, 
    getRelatedProducts,
    isLoading, 
    fetchProducts 
  } = useProductStore();
  const { addItem } = useCartStore();

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  useEffect(() => {
    // Reset state when product changes
    setSelectedImage(0);
    setSelectedVariant(null);
    setQuantity(1);
  }, [slug]);

  const product = slug ? getProductBySlug(slug) : undefined;
  const relatedProducts = product ? getRelatedProducts(product, 4) : [];

  // Loading state
  if (isLoading) {
    return (
      <div className="container py-16 text-center">
        <p>Cargando producto...</p>
      </div>
    );
  }

  // Product not found
  if (!product) {
    return (
      <div className="container py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Producto no encontrado</h1>
        <p className="mb-8">El producto que estás buscando no existe o ha sido eliminado.</p>
        <Button onClick={() => navigate('/')}>Volver a la tienda</Button>
      </div>
    );
  }

  // Handle potential missing properties
  const images = product.images || [];
  const variants = product.variants || [];
  const salePrice = 'salePrice' in product ? product.salePrice : undefined;
  const basePrice = 'basePrice' in product ? product.basePrice : product.price;
  const discountPercentage = salePrice ? Math.round(((basePrice - salePrice) / basePrice) * 100) : 0;

  // Helper function to validate adding to cart
  const canAddToCart = selectedVariant !== null && selectedVariant.inStock;

  // Handle add to cart action
  const handleAddToCart = () => {
    if (product && selectedVariant && canAddToCart) {
      const productImage = images.length > 0 ? images[0].url : '/assets/products/placeholder.jpg';
      addItem(
        product.id,
        product.name,
        productImage,
        selectedVariant,
        salePrice || basePrice,
        quantity
      );
      // Show confirmation toast or modal here if needed
    }
  };

  return (
    <div className="container py-8">
      {/* Back button */}
      <div className="mb-6">
        <Button
          variant="ghost"
          size="sm"
          className="flex items-center text-muted-foreground hover:text-foreground"
          onClick={() => navigate(-1)}
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Volver
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {/* Product Images */}
        <div className="space-y-4">
          {/* Main image */}
          <div className="aspect-square overflow-hidden rounded-lg border bg-muted">
            <img
              src={images[selectedImage]?.url || '/assets/products/placeholder.jpg'}
              alt={images[selectedImage]?.alt || product.name}
              className="h-full w-full object-cover"
            />
          </div>

          {/* Thumbnail images */}
          {images.length > 1 && (
            <div className="flex space-x-2 overflow-auto pb-2">
              {images.map((image, index) => (
                <button
                  key={index}
                  className={`relative aspect-square w-20 overflow-hidden rounded-md border bg-muted ${
                    selectedImage === index ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => setSelectedImage(index)}
                >
                  <img
                    src={image.url}
                    alt={image.alt || `${product.name} - Imagen ${index + 1}`}
                    className="h-full w-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          {/* Basic info */}
          <div>
            <h1 className="text-3xl font-bold">{product.name}</h1>
            
            {'brand' in product && product.brand && (
              <p className="text-muted-foreground">{product.brand}</p>
            )}
            
            {'rating' in product && product.rating && (
              <div className="flex items-center mt-2">
                <div className="flex text-amber-500 mr-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(product.rating) ? 'fill-current' : ''
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">
                  {product.rating.toFixed(1)} ({Math.floor(product.rating * 10)} reseñas)
                </span>
              </div>
            )}
          </div>

          {/* Price */}
          <div className="flex items-end gap-2">
            {salePrice ? (
              <>
                <span className="text-3xl font-bold text-red-600">
                  {salePrice.toFixed(2)} €
                </span>
                <span className="text-xl text-muted-foreground line-through">
                  {basePrice.toFixed(2)} €
                </span>
                <Badge variant="destructive" className="ml-2">
                  -{discountPercentage}%
                </Badge>
              </>
            ) : (
              <span className="text-3xl font-bold">{basePrice.toFixed(2)} €</span>
            )}
          </div>

          {/* Variants */}
          {variants.length > 0 && (
            <div>
              <h3 className="text-sm font-medium mb-3">Tallas Disponibles</h3>
              <div className="flex flex-wrap gap-2">
                {variants.map((variant) => (
                  <Button
                    key={variant.id}
                    type="button"
                    size="sm"
                    variant={selectedVariant?.id === variant.id ? "default" : "outline"}
                    className={`min-w-[4rem] ${!variant.inStock ? 'opacity-50 cursor-not-allowed' : ''}`}
                    disabled={!variant.inStock}
                    onClick={() => setSelectedVariant(variant)}
                  >
                    {variant.name}
                    {!variant.inStock && <span className="block text-xs">Agotado</span>}
                  </Button>
                ))}
              </div>
              {!selectedVariant && (
                <p className="text-sm text-muted-foreground mt-2">
                  Selecciona una talla para continuar
                </p>
              )}
            </div>
          )}

          {/* Quantity selector */}
          <div>
            <h3 className="text-sm font-medium mb-3">Cantidad</h3>
            <div className="flex items-center border rounded-md w-32">
              <Button
                variant="ghost"
                size="sm"
                className="rounded-none"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
              >
                -
              </Button>
              <span className="flex-1 text-center">{quantity}</span>
              <Button
                variant="ghost"
                size="sm"
                className="rounded-none"
                onClick={() => setQuantity(Math.min(10, quantity + 1))}
              >
                +
              </Button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <Button
              onClick={handleAddToCart}
              disabled={!canAddToCart}
              className="flex-1"
              size="lg"
            >
              <ShoppingCart className="h-5 w-5 mr-2" />
              Añadir al carrito
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="flex-1 sm:flex-none"
            >
              <Heart className="h-5 w-5 mr-2" />
              Favorito
            </Button>
            <WhatsAppButton 
              productName={product.name} 
              variant={selectedVariant?.name || ''} 
              className="flex-1 sm:flex-none"
              size="lg"
            />
          </div>

          {/* Purchase information */}
          <div className="grid grid-cols-2 gap-4 py-4 border-t border-b">
            <div className="flex items-start gap-2">
              <Truck className="h-5 w-5 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="text-sm font-medium">Envío gratis</p>
                <p className="text-xs text-muted-foreground">En pedidos superiores a 50€</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Shield className="h-5 w-5 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="text-sm font-medium">Pago seguro</p>
                <p className="text-xs text-muted-foreground">Transacciones seguras</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <RotateCcw className="h-5 w-5 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="text-sm font-medium">Devoluciones fáciles</p>
                <p className="text-xs text-muted-foreground">Hasta 30 días</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Check className="h-5 w-5 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="text-sm font-medium">Calidad garantizada</p>
                <p className="text-xs text-muted-foreground">Productos seleccionados</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Product Details Tabs */}
      <Card className="mb-12">
        <Tabs defaultValue="description">
          <TabsList className="w-full justify-start border-b rounded-none bg-transparent h-auto p-0">
            <TabsTrigger 
              value="description" 
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-3 px-4"
            >
              Descripción
            </TabsTrigger>
            <TabsTrigger 
              value="details" 
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-3 px-4"
            >
              Detalles
            </TabsTrigger>
            <TabsTrigger 
              value="shipping" 
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-3 px-4"
            >
              Envío y devoluciones
            </TabsTrigger>
          </TabsList>
          <TabsContent value="description" className="p-6">
            <p className="text-muted-foreground">{product.description}</p>
          </TabsContent>
          <TabsContent value="details" className="p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium mb-2">Especificaciones</h4>
                <ul className="space-y-2 text-muted-foreground">
                  <li><span className="font-medium text-foreground">Marca:</span> {product.brand}</li>
                  <li>
                    <span className="font-medium text-foreground">Categoría:</span> {product.category.charAt(0).toUpperCase() + product.category.slice(1)}
                  </li>
                  <li>
                    <span className="font-medium text-foreground">Etiquetas:</span> {product.tags?.join(', ')}
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Cuidados</h4>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  <li>Lavar a máquina a 30°</li>
                  <li>No usar lejía</li>
                  <li>Planchar a temperatura media</li>
                  <li>No lavar en seco</li>
                </ul>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="shipping" className="p-6">
            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Envío</h4>
                <p className="text-muted-foreground">
                  Ofrecemos envío gratuito en todos los pedidos superiores a 50€. Para pedidos menores, 
                  el costo de envío es de 4,99€. Los tiempos de entrega estimados son de 3-5 días laborables.
                </p>
              </div>
              <div>
                <h4 className="font-medium mb-2">Devoluciones</h4>
                <p className="text-muted-foreground">
                  Aceptamos devoluciones dentro de los 30 días posteriores a la recepción del pedido. 
                  Los artículos deben estar en su estado original, sin usar y con todas las etiquetas. 
                  <Link to="/politica-devoluciones" className="text-primary hover:underline ml-1">
                    Ver política de devoluciones completa
                  </Link>.
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </Card>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">También te puede gustar</h2>
          <ProductGrid products={relatedProducts} columns={{ sm: 2, md: 3, lg: 4 }} />
        </div>
      )}

      {/* Call to Action */}
      <div className="bg-muted p-8 rounded-lg text-center mb-8">
        <h2 className="text-2xl font-bold mb-4">¿Necesitas ayuda con tu elección?</h2>
        <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
          Nuestro equipo está disponible para resolver todas tus dudas y ayudarte a encontrar la prenda perfecta.
        </p>
        <div className="flex justify-center gap-4 flex-wrap">
          <WhatsAppButton size="lg">Contáctanos por WhatsApp</WhatsAppButton>
          <Button variant="outline" size="lg" asChild>
            <Link to="/contacto">Ver más opciones de contacto</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}