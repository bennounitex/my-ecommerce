import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

export default function ReturnPolicy() {
  return (
    <div className="container px-4 md:px-6 py-8 md:py-12">
      <Breadcrumb className="mb-6">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <Link to="/">
                <Home className="h-4 w-4" />
                <span className="sr-only">Inicio</span>
              </Link>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <span>Política de Devoluciones</span>
            </BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl md:text-4xl font-bold mb-6">Política de Devoluciones</h1>
        
        <p className="text-muted-foreground mb-6">
          En BENNOUNI TEX queremos asegurarnos de que estés completamente satisfecha con tu compra. Si por alguna razón no estás conforme con los productos recibidos, ofrecemos las siguientes opciones para devoluciones y cambios.
        </p>
        
        <div className="space-y-8">
          <section>
            <h2 className="text-xl font-semibold mb-3">Información General</h2>
            <p className="text-muted-foreground mb-4">
              Todas las devoluciones deben realizarse dentro de los 14 días naturales a partir de la recepción del pedido. Los artículos devueltos deben estar en su estado original, sin usar, con las etiquetas originales y en su embalaje original.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
              <div className="bg-muted/50 p-4 rounded-lg text-center space-y-2">
                <div className="text-primary text-xl font-bold">14 días</div>
                <p className="text-sm text-muted-foreground">
                  Plazo para devoluciones desde la recepción del pedido
                </p>
              </div>
              <div className="bg-muted/50 p-4 rounded-lg text-center space-y-2">
                <div className="text-primary text-xl font-bold">100%</div>
                <p className="text-sm text-muted-foreground">
                  Devolución del importe en compras con defectos
                </p>
              </div>
              <div className="bg-muted/50 p-4 rounded-lg text-center space-y-2">
                <div className="text-primary text-xl font-bold">Gratis</div>
                <p className="text-sm text-muted-foreground">
                  Devoluciones por productos defectuosos
                </p>
              </div>
            </div>
          </section>

          <Separator />
          
          <section>
            <h2 className="text-xl font-semibold mb-3">Proceso de Devolución</h2>
            <ol className="list-decimal list-inside space-y-3 text-muted-foreground">
              <li>
                <span className="font-medium text-foreground">Contacta con nuestro servicio de atención al cliente:</span> Puedes hacerlo a través de nuestro WhatsApp (+34 600 000 000), por correo electrónico (devoluciones@bennounitex.com) o llamando al +34 932 556 789.
              </li>
              <li>
                <span className="font-medium text-foreground">Solicita un número de autorización de devolución (RMA):</span> Nuestro equipo te proporcionará este número que deberás incluir en tu paquete de devolución.
              </li>
              <li>
                <span className="font-medium text-foreground">Empaqueta los artículos:</span> Asegúrate de que los productos estén en su estado original, con todas las etiquetas y el embalaje original.
              </li>
              <li>
                <span className="font-medium text-foreground">Envía el paquete:</span> Utiliza el servicio de mensajería indicado por nuestro equipo de atención al cliente, incluyendo el número RMA en el exterior del paquete.
              </li>
              <li>
                <span className="font-medium text-foreground">Seguimiento del proceso:</span> Una vez recibida la devolución, procesaremos el reembolso o cambio en un plazo máximo de 5 días laborables.
              </li>
            </ol>
          </section>

          <Separator />
          
          <section>
            <h2 className="text-xl font-semibold mb-3">Condiciones y Exclusiones</h2>
            <ul className="list-disc list-inside space-y-3 text-muted-foreground">
              <li>Los artículos en promoción o rebajados pueden tener condiciones especiales de devolución, que se especificarán en cada caso.</li>
              <li>Por razones de higiene, no se aceptan devoluciones de ropa interior, trajes de baño o accesorios para el cabello, a menos que presenten defectos de fabricación.</li>
              <li>Los productos personalizados o hechos a medida no son aptos para devolución, salvo que presenten defectos.</li>
              <li>No nos hacemos responsables de devoluciones perdidas en tránsito. Asegúrate de obtener un comprobante de envío.</li>
              <li>Las devoluciones por productos defectuosos o errores en el envío serán gratuitas para el cliente.</li>
            </ul>
          </section>

          <Separator />
          
          <section>
            <h2 className="text-xl font-semibold mb-3">Reembolsos</h2>
            <p className="text-muted-foreground mb-4">
              Los reembolsos se procesarán mediante el mismo método de pago utilizado para la compra original. El tiempo para que el reembolso aparezca en tu cuenta dependerá de tu entidad bancaria:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li>Tarjetas de crédito/débito: 3-5 días hábiles después de procesar la devolución.</li>
              <li>PayPal: 1-2 días hábiles después de procesar la devolución.</li>
              <li>Transferencia bancaria: 3-7 días hábiles después de procesar la devolución.</li>
            </ul>
            <p className="text-muted-foreground mt-4">
              El coste de envío original no se reembolsará a menos que la devolución sea debido a un artículo defectuoso o a un error por nuestra parte.
            </p>
          </section>

          <Separator />
          
          <section>
            <h2 className="text-xl font-semibold mb-3">Cambios</h2>
            <p className="text-muted-foreground mb-4">
              Si prefieres cambiar el artículo por otro color, talla o modelo, sigue el mismo proceso de devolución indicando en tu solicitud que deseas un cambio. Ten en cuenta:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground mb-4">
              <li>Los cambios están sujetos a disponibilidad de stock.</li>
              <li>Si el nuevo artículo tiene un precio superior, deberás abonar la diferencia.</li>
              <li>Si el nuevo artículo tiene un precio inferior, te reembolsaremos la diferencia.</li>
            </ul>
            <p className="text-muted-foreground">
              Para cambios de talla, te recomendamos consultar nuestra guía de tallas o contactar con nuestro servicio de atención al cliente para recibir asesoramiento personalizado.
            </p>
          </section>

          <Separator />
          
          <section>
            <h2 className="text-xl font-semibold mb-3">Preguntas Frecuentes</h2>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>¿Cuánto tiempo tarda en procesarse mi devolución?</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  Una vez que recibamos tu devolución, el procesamiento tomará entre 2 y 5 días laborables. Después, el tiempo para que el reembolso aparezca en tu cuenta dependerá de tu entidad bancaria.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger>¿Puedo devolver un artículo comprado en oferta?</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  Sí, los artículos en oferta pueden ser devueltos dentro del plazo de 14 días, siempre que estén en su estado original. Sin embargo, algunos productos marcados como "Oferta Final" pueden tener restricciones de devolución, lo cual se indicará claramente en la descripción del producto.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger>¿Qué debo hacer si recibo un producto defectuoso?</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  Si recibes un producto defectuoso, contacta inmediatamente con nuestro servicio de atención al cliente incluyendo fotos del defecto. Organizaremos la recogida y te enviaremos un reemplazo o procesaremos un reembolso completo sin coste adicional para ti.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger>¿Qué ocurre si ya han pasado los 14 días?</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  Después del período de 14 días, normalmente no aceptamos devoluciones. Sin embargo, para productos defectuosos, la garantía legal se extiende por 2 años. En casos excepcionales, podemos ofrecer un crédito de tienda, evaluando cada situación individualmente.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-5">
                <AccordionTrigger>¿Puedo cambiar un producto por otro diferente?</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  Sí, puedes solicitar un cambio por otro producto. Si el nuevo producto tiene un precio diferente, se ajustará la diferencia ya sea con un cargo adicional o un reembolso parcial. El proceso se gestiona como una devolución seguida de un nuevo pedido.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </section>

          <Separator />
          
          <section className="bg-muted/50 p-6 rounded-lg">
            <h2 className="text-xl font-semibold mb-3">Contacta con Nosotros</h2>
            <p className="text-muted-foreground mb-4">
              Si tienes cualquier duda sobre nuestra política de devoluciones o necesitas asistencia con una devolución, no dudes en contactarnos:
            </p>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start">
                <span className="mr-2">📱</span>
                <span>WhatsApp: +34 600 000 000</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2">📧</span>
                <span>Email: devoluciones@bennounitex.com</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2">☎️</span>
                <span>Teléfono: +34 932 556 789 (Lun-Vie, 9:00-18:00)</span>
              </li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}