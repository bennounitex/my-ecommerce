import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useProductStore } from '@/store/productStore';
import ProductGrid from '@/components/product/ProductGrid';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search as SearchIcon } from 'lucide-react';

export default function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const { products, isLoading, fetchProducts, getProductsBySearch } = useProductStore();
  const [searchQuery, setSearchQuery] = useState(query);
  const [searchResults, setSearchResults] = useState<ReturnType<typeof getProductsBySearch>>([]);
  
  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);
  
  useEffect(() => {
    if (query) {
      setSearchQuery(query);
      setSearchResults(getProductsBySearch(query));
    }
  }, [query, products, getProductsBySearch]);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSearchParams({ q: searchQuery.trim() });
    }
  };
  
  if (isLoading) {
    return (
      <div className="container py-16 text-center">
        <p>Cargando resultados...</p>
      </div>
    );
  }
  
  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">Resultados de búsqueda</h1>
      
      <form onSubmit={handleSearch} className="flex mb-8 max-w-md">
        <Input
          type="search"
          placeholder="Buscar productos..."
          className="mr-2"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <Button type="submit">
          <SearchIcon className="h-4 w-4 mr-2" />
          Buscar
        </Button>
      </form>
      
      {query ? (
        <>
          <p className="text-muted-foreground mb-6">
            {searchResults.length === 0
              ? 'No se encontraron productos que coincidan con tu búsqueda.'
              : `Se encontraron ${searchResults.length} productos para "${query}"`}
          </p>
          
          {searchResults.length > 0 && (
            <ProductGrid
              products={searchResults}
              columns={{ sm: 2, md: 3, lg: 4 }}
            />
          )}
          
          {searchResults.length === 0 && (
            <div className="py-16 text-center">
              <p className="mb-6 text-lg">No encontramos lo que buscas</p>
              <p className="mb-8 text-muted-foreground">
                Prueba con términos más generales o revisa nuestras categorías
              </p>
              <Button onClick={() => window.history.back()}>
                Volver a la página anterior
              </Button>
            </div>
          )}
        </>
      ) : (
        <div className="py-16 text-center">
          <p className="mb-6 text-lg">Busca entre nuestros productos</p>
          <p className="text-muted-foreground">
            Escribe lo que estás buscando en el campo de búsqueda
          </p>
        </div>
      )}
    </div>
  );
}