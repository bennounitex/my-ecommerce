import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { InfoIcon } from 'lucide-react';

export default function Shipping() {
  return (
    <div className="container px-4 md:px-6 py-8 md:py-12">
      <Breadcrumb className="mb-6">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <Link to="/">
                <Home className="h-4 w-4" />
                <span className="sr-only">Inicio</span>
              </Link>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <span>Envío y Entrega</span>
            </BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl md:text-4xl font-bold mb-6">Envío y Entrega</h1>
        
        <p className="text-muted-foreground mb-6">
          En BENNOUNI TEX nos esforzamos por ofrecer un servicio de envío rápido y eficiente para que puedas disfrutar de tus compras lo antes posible. A continuación encontrarás toda la información sobre nuestras opciones de envío y entrega.
        </p>
        
        <Tabs defaultValue="national" className="mb-8">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="national">Envíos Nacionales</TabsTrigger>
            <TabsTrigger value="international">Envíos Internacionales</TabsTrigger>
          </TabsList>
          <TabsContent value="national" className="pt-4">
            <div className="space-y-4">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-2">Envío Estándar</h3>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="text-center p-3 bg-muted/50 rounded-md">
                      <p className="text-sm text-muted-foreground">Tiempo de entrega</p>
                      <p className="font-medium">2-4 días laborables</p>
                    </div>
                    <div className="text-center p-3 bg-muted/50 rounded-md">
                      <p className="text-sm text-muted-foreground">Coste</p>
                      <p className="font-medium">3,95 € (Gratis para pedidos +50€)</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Servicio de entrega a través de Correos Express. Incluye seguimiento del envío y notificaciones por email y SMS.
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-2">Envío Express</h3>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="text-center p-3 bg-muted/50 rounded-md">
                      <p className="text-sm text-muted-foreground">Tiempo de entrega</p>
                      <p className="font-medium">24-48 horas laborables</p>
                    </div>
                    <div className="text-center p-3 bg-muted/50 rounded-md">
                      <p className="text-sm text-muted-foreground">Coste</p>
                      <p className="font-medium">6,95 €</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Servicio de entrega premium a través de SEUR. Incluye seguimiento del envío, selección de franja horaria y notificaciones por email y SMS.
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-2">Recogida en Tienda</h3>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="text-center p-3 bg-muted/50 rounded-md">
                      <p className="text-sm text-muted-foreground">Tiempo de disponibilidad</p>
                      <p className="font-medium">24-48 horas laborables</p>
                    </div>
                    <div className="text-center p-3 bg-muted/50 rounded-md">
                      <p className="text-sm text-muted-foreground">Coste</p>
                      <p className="font-medium">Gratuito</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Recoge tu pedido en cualquiera de nuestras tiendas físicas. Te avisaremos cuando tu pedido esté disponible para recoger.
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="international" className="pt-4">
            <div className="space-y-4">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-2">Europa</h3>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="text-center p-3 bg-muted/50 rounded-md">
                      <p className="text-sm text-muted-foreground">Tiempo de entrega</p>
                      <p className="font-medium">3-7 días laborables</p>
                    </div>
                    <div className="text-center p-3 bg-muted/50 rounded-md">
                      <p className="text-sm text-muted-foreground">Coste</p>
                      <p className="font-medium">9,95 € (Gratis para pedidos +100€)</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Envíos a todos los países de la Unión Europea. Incluye seguimiento del envío y notificaciones por email.
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-2">Internacional</h3>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="text-center p-3 bg-muted/50 rounded-md">
                      <p className="text-sm text-muted-foreground">Tiempo de entrega</p>
                      <p className="font-medium">7-15 días laborables</p>
                    </div>
                    <div className="text-center p-3 bg-muted/50 rounded-md">
                      <p className="text-sm text-muted-foreground">Coste</p>
                      <p className="font-medium">19,95 €</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Envíos a países fuera de la Unión Europea. Los gastos de aduana e impuestos aplicables corren a cargo del cliente.
                  </p>
                </CardContent>
              </Card>
              
              <Alert className="mt-6">
                <InfoIcon className="h-4 w-4" />
                <AlertTitle>Importante</AlertTitle>
                <AlertDescription>
                  Los envíos internacionales pueden estar sujetos a impuestos de aduana y/o IVA adicionales, que serán responsabilidad del cliente y se abonarán en el momento de la entrega. El tiempo de entrega puede variar dependiendo de los procedimientos aduaneros de cada país.
                </AlertDescription>
              </Alert>
            </div>
          </TabsContent>
        </Tabs>

        <Separator className="my-8" />
        
        <section className="space-y-6">
          <h2 className="text-2xl font-semibold">Información Adicional</h2>
          
          <div>
            <h3 className="text-lg font-medium mb-3">Seguimiento de Pedidos</h3>
            <p className="text-muted-foreground mb-4">
              Una vez que tu pedido haya sido enviado, recibirás un correo electrónico con el número de seguimiento y las instrucciones para rastrear tu envío. También puedes comprobar el estado de tu pedido en la sección "Mi Cuenta" de nuestra web.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-3">Horarios de Entrega</h3>
            <p className="text-muted-foreground mb-4">
              Las entregas se realizan de lunes a viernes, en horario de 9:00 a 19:00. Para los envíos Express, puedes seleccionar una franja horaria específica durante el proceso de compra.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-3">Zonas de Entrega</h3>
            <p className="text-muted-foreground mb-2">
              Realizamos envíos a toda la península, Islas Baleares, Islas Canarias, Ceuta y Melilla:
            </p>
            <ul className="list-disc list-inside text-muted-foreground ml-2 space-y-1">
              <li>Península: Tiempos y costes estándar indicados arriba.</li>
              <li>Islas Baleares: Añade 1 día adicional y 1€ al coste estándar.</li>
              <li>Islas Canarias, Ceuta y Melilla: Añade 2-3 días adicionales y 5€ al coste estándar. Pueden aplicarse impuestos locales.</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-3">Entrega no Completada</h3>
            <p className="text-muted-foreground mb-4">
              Si no estás presente en el momento de la entrega:
            </p>
            <ul className="list-disc list-inside text-muted-foreground ml-2 space-y-1">
              <li>El mensajero intentará una segunda entrega al día siguiente laborable.</li>
              <li>Si el segundo intento no tiene éxito, recibirás un aviso con instrucciones para recoger tu paquete en la oficina de mensajería más cercana.</li>
              <li>Los paquetes permanecerán disponibles para recogida durante 15 días antes de ser devueltos a nuestras instalaciones.</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-3">Envíos Múltiples</h3>
            <p className="text-muted-foreground">
              En ocasiones, tu pedido puede dividirse en varios envíos si los productos no están disponibles en el mismo centro logístico. En estos casos:
            </p>
            <ul className="list-disc list-inside text-muted-foreground ml-2 space-y-1">
              <li>Solo se cobrará una vez el gasto de envío.</li>
              <li>Recibirás notificaciones por separado para cada parte del envío.</li>
              <li>Los tiempos de entrega pueden variar para cada parte del pedido.</li>
            </ul>
          </div>
        </section>

        <Separator className="my-8" />
        
        <section className="space-y-6">
          <h2 className="text-2xl font-semibold">Preguntas Frecuentes</h2>
          
          <div>
            <h3 className="text-lg font-medium mb-2">¿Cómo puedo saber cuándo llegará mi pedido?</h3>
            <p className="text-muted-foreground">
              Recibirás un correo electrónico con la confirmación del envío y un número de seguimiento que te permitirá rastrear tu paquete en tiempo real. También recibirás notificaciones SMS si has proporcionado tu número de teléfono.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-2">¿Puedo cambiar la dirección de entrega después de realizar el pedido?</h3>
            <p className="text-muted-foreground">
              Solo es posible modificar la dirección de entrega si el pedido aún no ha sido procesado. Contacta con nuestro servicio de atención al cliente lo antes posible para solicitar el cambio.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-2">¿Qué ocurre si mi pedido llega dañado?</h3>
            <p className="text-muted-foreground">
              Si recibes un producto dañado, contacta con nuestro servicio de atención al cliente dentro de las 48 horas posteriores a la recepción, adjuntando fotos del paquete y del producto dañado. Organizaremos una recogida y reemplazo sin coste adicional.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-2">¿Realizan envíos en días festivos?</h3>
            <p className="text-muted-foreground">
              No realizamos envíos en días festivos nacionales ni fines de semana. Los pedidos realizados durante estos días se procesarán el siguiente día laborable.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-2">¿Puedo solicitar un envío urgente si lo necesito para una fecha específica?</h3>
            <p className="text-muted-foreground">
              Para necesidades urgentes, recomendamos seleccionar la opción de Envío Express durante el proceso de compra. Si necesitas tu pedido para una fecha específica, contacta con nuestro servicio de atención al cliente y haremos todo lo posible por ayudarte, aunque no podemos garantizar entregas en fechas exactas.
            </p>
          </div>
        </section>

        <Separator className="my-8" />
        
        <section className="bg-muted/50 p-6 rounded-lg">
          <h2 className="text-xl font-semibold mb-3">Contacta con Nosotros</h2>
          <p className="text-muted-foreground mb-4">
            Si tienes cualquier duda sobre el estado de tu envío o necesitas información adicional, no dudes en contactarnos:
          </p>
          <ul className="space-y-3 text-muted-foreground">
            <li className="flex items-start">
              <span className="mr-2">📱</span>
              <span>WhatsApp: +34 600 000 000</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">📧</span>
              <span>Email: envios@bennounitex.com</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">☎️</span>
              <span>Teléfono: +34 932 556 789 (Lun-Vie, 9:00-18:00)</span>
            </li>
          </ul>
        </section>
      </div>
    </div>
  );
}