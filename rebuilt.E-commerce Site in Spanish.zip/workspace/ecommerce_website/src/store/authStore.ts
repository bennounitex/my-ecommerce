import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User, AuthState } from '@/types';

const initialAuthState: AuthState = {
  user: null,
  isAuthenticated: false,
  loading: false,
  error: null,
};

export const useAuthStore = create<AuthState & {
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, name: string, lastName: string, password: string) => Promise<void>;
  logout: () => void;
  updateProfile: (userData: Partial<User>) => void;
  clearError: () => void;
}>()(
  persist(
    (set) => ({
      ...initialAuthState,
      
      login: async (email: string, password: string) => {
        set({ loading: true, error: null });
        try {
          // In a real app, this would be an API call
          // For now, we'll simulate authentication
          const mockUser: User = {
            id: '1',
            email,
            name: 'Usuario',
            lastName: 'Demo',
            role: 'customer',
            addresses: [],
            createdAt: new Date(),
            updatedAt: new Date()
          };
          
          // Simulate API delay
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set({ user: mockUser, isAuthenticated: true, loading: false });
        } catch (error) {
          set({ error: error instanceof Error ? error.message : 'Error al iniciar sesión', loading: false });
        }
      },
      
      register: async (email: string, name: string, lastName: string, password: string) => {
        set({ loading: true, error: null });
        try {
          // In a real app, this would be an API call
          // For now, we'll simulate registration
          const mockUser: User = {
            id: '1',
            email,
            name,
            lastName,
            role: 'customer',
            addresses: [],
            createdAt: new Date(),
            updatedAt: new Date()
          };
          
          // Simulate API delay
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set({ user: mockUser, isAuthenticated: true, loading: false });
        } catch (error) {
          set({ error: error instanceof Error ? error.message : 'Error al registrarse', loading: false });
        }
      },
      
      logout: () => {
        set(initialAuthState);
      },
      
      updateProfile: (userData: Partial<User>) => {
        set((state) => ({
          user: state.user ? { ...state.user, ...userData } : null
        }));
      },
      
      clearError: () => {
        set({ error: null });
      }
    }),
    {
      name: 'auth-storage',
      // Only store specific fields in localStorage
      partialize: (state) => ({ 
        user: state.user,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);